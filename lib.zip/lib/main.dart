import 'package:flutter/material.dart';
import 'package:example_tmap_navi/app.dart';

void main() {
  runApp(const TmapExampleApp());
}
